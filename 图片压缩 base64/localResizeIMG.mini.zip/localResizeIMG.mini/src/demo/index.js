(function() {
	var input = document.querySelector('input');

	input.onchange = function() {
		lrz(this.files[0], {
			width: 400
		}, function(results) {

			$("#myimg").attr("src", results.base64);
			var base64Str = results.base64;
			var msg = base64Str.split(",")[0];
			console.log(results.base64);
	
		});
	};

})();